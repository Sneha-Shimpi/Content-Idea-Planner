const API = "http://localhost:3000/posts";

async function loadPosts() {
  const res = await fetch(API);
  const data = await res.json();

  const container = document.getElementById("posts");
  container.innerHTML = "";

  data.forEach(post => {
    container.innerHTML += `
      <div class="post">
        <h3>${post.title}</h3>
        <p>${post.platform} | ${post.date}</p>
        <p>Status: ${post.posted ? "✅ Posted" : "⏳ Pending"}</p>
        ${!post.posted ? `<button onclick="markPosted(${post.id})">Mark Posted</button>` : ""}
      </div>
    `;
  });
}

async function addPost() {
  const title = document.getElementById("title").value;
  const platform = document.getElementById("platform").value;
  const date = document.getElementById("date").value;

  await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, platform, date, posted: false })
  });

  loadPosts();
}

async function markPosted(id) {
  await fetch(`${API}/${id}`, { method: "PUT" });
  loadPosts();
}

loadPosts();
