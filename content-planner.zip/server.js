const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static("public"));

let posts = [];

app.get("/posts", (req, res) => {
  res.json(posts);
});

app.post("/posts", (req, res) => {
  const post = { id: Date.now(), ...req.body };
  posts.push(post);
  res.json(post);
});

app.put("/posts/:id", (req, res) => {
  posts = posts.map(p =>
    p.id == req.params.id ? { ...p, posted: true } : p
  );
  res.json({ message: "Updated" });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
